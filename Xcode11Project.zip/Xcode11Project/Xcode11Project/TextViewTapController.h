//
//  TextViewTapController.h
//  2222
//
//  Created by Bin Shang on 2020/4/16.
//  Copyright © 2020 Bin Shang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextViewTapController : UIViewController


@end

